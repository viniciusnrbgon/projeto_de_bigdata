import csv
import json
import os
import sqlite3
from datetime import datetime
import pandas as pd

LOG_LINES = []

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    LOG_LINES.append(line)

def task_1_ingestao_json():
    log("=== TASK 1: INGESTÃO BRONZE (CSV -> MENSAGENS JSON) ===")
    os.makedirs("datalake/streaming_topic", exist_ok=True)
    registros = []
    with open("datalake/bronze/airquality.csv", "r", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter=";")
        for row in reader:
            if row.get("Date"):
                registros.append(row)
    with open("datalake/streaming_topic/airquality_raw.json", "w", encoding="utf-8") as out:
        json.dump(registros, out, indent=2, ensure_ascii=False)
    log(f"[OK] {len(registros)} mensagens JSON publicadas no tópico 'airquality_raw'.")

def task_2_processamento_silver_gold():
    log("=== TASK 2: PROCESSAMENTO ETL (SILVER & GOLD PARQUET) ===")
    os.makedirs("datalake/silver", exist_ok=True)
    os.makedirs("datalake/gold", exist_ok=True)

    df = pd.read_json("datalake/streaming_topic/airquality_raw.json", dtype=False)

    df["event_timestamp"] = pd.to_datetime(
        df["Date"].astype(str) + " " + df["Time"].astype(str),
        format="%d/%m/%Y %H.%M.%S"
    )
    df["hour_of_day"] = df["event_timestamp"].dt.hour

    num_cols = {
        "CO(GT)": "co_gt",
        "C6H6(GT)": "c6h6_gt",
        "NOx(GT)": "nox_gt",
        "NO2(GT)": "no2_gt",
        "T": "temperature",
        "RH": "relative_humidity"
    }
    for orig, dest in num_cols.items():
        df[dest] = df[orig].astype(str).str.replace(",", ".").astype(float)

    df_silver = df[(df["co_gt"] > -100) & (df["temperature"] > -100)].copy()

    def classifica_ar(co):
        if co >= 3.5:
            return "ALERTA_CRITICO"
        elif co >= 2.0:
            return "MODERADO"
        return "BOM"

    df_silver["air_status"] = df_silver["co_gt"].apply(classifica_ar)
    cols_finais = [
        "event_timestamp", "hour_of_day", "co_gt", "c6h6_gt",
        "nox_gt", "no2_gt", "temperature", "relative_humidity", "air_status"
    ]
    df_silver = df_silver[cols_finais]

    df_silver.to_parquet("datalake/silver/airquality_clean.parquet", index=False)
    log("[OK] Camada SILVER salva em 'datalake/silver/airquality_clean.parquet'.")

    df_gold = df_silver.groupby("hour_of_day", as_index=False).agg(
        avg_co=("co_gt", "mean"),
        avg_temp=("temperature", "mean"),
        avg_rh=("relative_humidity", "mean"),
        total_readings=("co_gt", "count")
    ).round(2)
    df_gold.to_parquet("datalake/gold/airquality_hourly.parquet", index=False)
    log("[OK] Camada GOLD salva em 'datalake/gold/airquality_hourly.parquet'.")

    conn = sqlite3.connect("datalake/analytics.db")
    df_silver.to_sql("air_quality_gold", conn, if_exists="replace", index=False)
    conn.close()
    log("[OK] Dados persistidos no banco analítico 'datalake/analytics.db'.")

def task_3_validacao():
    log("=== TASK 3: VALIDAÇÃO DE INTEGRIDADE DO PIPELINE ===")
    assert os.path.exists("datalake/silver/airquality_clean.parquet"), "Erro: Silver Parquet ausente!"
    assert os.path.exists("datalake/gold/airquality_hourly.parquet"), "Erro: Gold Parquet ausente!"
    df_check = pd.read_parquet("datalake/silver/airquality_clean.parquet")
    log(f"[VALIDAÇÃO OK] Registros válidos: {len(df_check)} | Temp Média: {df_check['temperature'].mean():.1f}°C | CO Médio: {df_check['co_gt'].mean():.2f} mg/m³")

    os.makedirs("evidencias", exist_ok=True)
    with open("evidencias/execucao_pipeline.log", "w", encoding="utf-8") as lf:
        lf.write("\n".join(LOG_LINES))
    log("[OK] Log oficial salvo em 'evidencias/execucao_pipeline.log'.")

if __name__ == "__main__":
    task_1_ingestao_json()
    task_2_processamento_silver_gold()
    task_3_validacao()
